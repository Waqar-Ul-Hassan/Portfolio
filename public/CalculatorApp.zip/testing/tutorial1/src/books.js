export const books = [
{ id:1,
  img: 'https://s.turbifycdn.com/aah/islamicbookstore-com/the-salah-the-prophet-s-prayer-described-imam-naasiruddin-al-albaani-dakwah-books-hardcover-18.gif',
  author: 'Muhammad Nasir Al-Din Al-Albani',
  title: 'The Prophets Salah Described'
},
{ id:2,
  img: 'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1349092154i/16058135.jpg',
  author: 'Ibn Kathir, Ibn Al-Qayyim',
  title: 'The Spiritual Cure'
}
];